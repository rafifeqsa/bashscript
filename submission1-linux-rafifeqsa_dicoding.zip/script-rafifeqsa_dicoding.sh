#!/bin/bash
memory_total=$(free -m | awk 'NR==2{print $2}')
memory_used=$(free -m | awk 'NR==2{print $3}')
memory_free=$(free -m | awk 'NR==2{print $4}')
memory_shared=$(free -m | awk 'NR==2{print $5}')
memory_buffcache=$(free -m | awk 'NR==2{print $6}')
memory_available=$(free -m | awk 'NR==2{print $7}')
swap_total=$(free -m | awk 'NR==3{print $2}')
swap_used=$(free -m | awk 'NR==3{print $3}')
swap_free=$(free -m | awk 'NR==3{print $4}')

disk1gb=$(df -x tmpfs --si --output=source,used | awk 'NR==2{print $1,$2}')
disk2gb=$(df -x tmpfs --si --output=source,used | awk 'NR==3{print $1,$2}')

disk1percent=$( df -x tmpfs --output=source,pcent | awk 'NR==2{print $1,$2}')
disk2percent=$( df -x tmpfs --output=source,pcent | awk 'NR==3{print $1,$2}')

echo =========================================
echo Memory Usage MB
sleep 3s
echo Total Memory = $memory_total
echo Used Memory = $memory_used
echo Free Memory = $memory_free
echo Shared Memory = $memory_shared
echo Buff/Cache Memory = $memory_buffcache
echo Available Memory = $memory_available
echo Total Swap Memory = $swap_total
echo Used Swap Memory = $swap_used
echo Free Swap Memory = $swap_free
echo =========================================
echo Filesystem Use GB
sleep 3s
echo $disk1gb
echo $disk2gb
echo =========================================
echo Filesystem Use%
sleep 1m
echo $disk1percent
echo $disk2percent

